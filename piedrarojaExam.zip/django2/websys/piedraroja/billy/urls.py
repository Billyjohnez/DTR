from django.urls import path
from django.urls import path

from . import views 
from billy.views import classview 
app_name = 'billy'
urlpatterns = [
 
     path('class', classview.as_view(), name= 'cview'),
]